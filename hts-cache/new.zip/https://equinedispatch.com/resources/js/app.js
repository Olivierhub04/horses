<!DOCTYPE html>

<html
  lang="en"
  class="light-style"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Error - Pages</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="https://equinedispatch.com/front/assets/img/favicon.png">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="https://equinedispatch.com/admin/assets/fonts/boxicons.css" />
                            
    <!-- Core CSS -->
    <link rel="stylesheet" href="https://equinedispatch.com/admin/assets/css/core.css" class="template-customizer-core-css" />

    <link rel="stylesheet" href="https://equinedispatch.com/admin/assets/css/theme-default.css" class="template-customizer-theme-css" />

    <link rel="stylesheet" href="https://equinedispatch.com/admin/assets/css/demo.css" />

    <!-- Vendors CSS -->

    <link rel="stylesheet" href="https://equinedispatch.com/admin/assets/libs/perfect-scrollbar/perfect-scrollbar.css" />  
    <link rel="stylesheet" href="https://equinedispatch.com/admin/assets/libs/apex-charts/apex-charts.css" />
    <!-- Page -->
    
    <link rel="stylesheet" href="https://equinedispatch.com/admin/assets/css/pages/page-auth.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://equinedispatch.com/admin/assets/vendor/js/helpers.js"></script>   
    <script src="https://equinedispatch.com/admin/assets/js/config.js"></script>
  </head>

  <body>
    <!-- Content -->

  <!-- Error -->
    <div class="container-xxl container-p-y text-center">
      <div class="misc-wrapper">
        <h2 class="mb-2 mx-2">Page Not Found :(</h2>
        <p class="mb-4 mx-2">Oops! The requested URL was not found on this server.</p>
        <a href="https://equinedispatch.com/admin/dashboard" class="btn btn-primary">Back to home</a>
        <div class="mt-3">
          <img
            src="https://equinedispatch.com/admin/assets/img/illustrations/page-misc-error-light.png"
            alt="page-misc-error-light"
            width="500"
            class="img-fluid"
            data-app-dark-img="illustrations/page-misc-error-dark.png"
            data-app-light-img="illustrations/page-misc-error-light.png"
          />
        </div>
      </div>
    </div>
    <!-- /Error -->

    <!-- / Content -->


    <!-- Core JS -->
    <script src="https://equinedispatch.com/admin/assets/libs/jquery/jquery.js"></script>

    <script src="https://equinedispatch.com/admin/assets/libs/popper/popper.js"></script>

    <script src="https://equinedispatch.com/admin/assets/js/bootstrap.js"></script>
    <script src="https://equinedispatch.com/admin/assets/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="https://equinedispatch.com/admin/assets/js/menu.js"></script>
    <!-- endbuild -->
    
    <!-- Vendors JS -->
    <script src="https://equinedispatch.com/admin/assets/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="https://equinedispatch.com/admin/assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="https://equinedispatch.com/admin/assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  </body>
</html>

